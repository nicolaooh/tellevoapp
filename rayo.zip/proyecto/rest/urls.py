from collections import namedtuple
from django.urls import path
from .views import detalle_contacto, procesar_contactos
from .viewslogin import login




urlpatterns = [
    path('contactos',procesar_contactos, name="procesar_vehiculos"),
    path('contactos/<id>',detalle_contacto,name="detalle_contacto"),
    path('login',login,name="login")

]