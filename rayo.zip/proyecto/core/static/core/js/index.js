window.addEventListener('load', () => {

    const correo = "nicolascabellopineda@gmail.com";
    const pass = "123hola";
    
    btnInicio.addEventListener("click", () =>{
        const email     = document.getElementById("email").value;
        const password  = document.getElementById("password").value;
        const alerta = document.getElementById("alerta");

        if (email == correo && password == pass) {

            alert("Has iniciado sesion")

            

        } else {

            alerta.innerHTML = "";

            alerta.innerHTML =  
            `
            
            <div class="alert alert-danger" role="alert">
                Correo y/o contraseña incorrectos
            </div>
            
            `;

        }

    });

});

function iniciarMap(){
    var coord = {lat:-33.0481989 ,lng: -71.4390075};
    var map = new google.maps.Map(document.getElementById('map'),{
      zoom: 10,
      center: coord
    });
    var marker = new google.maps.Marker({
      position: coord,
      map: map
    });
}

