from django.urls import path
from .views import eliminarContacto, index
from .views import galeria
from .views import edgar
from .views import jose
from .views import guido
from .views import bdd
from .views import formularioContacto
from .views import modificarContacto
from .views import eliminarContacto




urlpatterns = [
    path('',index, name='index'),
    path('galeria/',galeria, name='galeria'),
    path('edgar/',edgar, name='edgar'),
    path('guido/',guido, name='guido'),
    path('jose/',jose, name='jose'),
    path('bdd/',bdd, name='bdd'),
    path('formularioContacto/',formularioContacto, name='formularioContacto'),
    path('modificarContacto/<id>',modificarContacto, name='modificarContacto'),
    path('eliminarContacto/<id>',eliminarContacto, name='eliminarContacto')
    
]