from django.db import models

# Create your models here.


class Contacto(models.Model):

    rut = models.IntegerField(primary_key=True,verbose_name='Rut')

    correoElectronico = models.CharField(max_length=100, verbose_name="CorreoElectronico")

    nombreContacto = models.CharField(max_length=100, verbose_name="Nombre")

    numeroTelefono = models.IntegerField(verbose_name="NumeroTelefono")

    mensajeContacto = models.CharField(max_length=500, verbose_name="Mensaje")



    def __str__(self):

        return self.nombreContacto