from core.forms import ContactoForms
from django import forms
from django.http import request
from django.shortcuts import redirect, render
from .models import Contacto



def index(request):
    return render(request,'core/index.html')

def galeria(request):
    return render(request,'core/galeria.html')

def guido(request):
    return render(request,'core/guido.html')

def edgar(request):
    return render(request,'core/edgar.html')

def jose(request):
    return render(request,'core/jose.html')

def bdd(request):
    return render(request,'core/bdd.html')

def formularioContacto(request):
    return render(request,'core/formularioContacto.html')

def modificarContacto(request):
    return render(request,'core/modificarContacto.html')









def bdd(request):
    contacto = Contacto.objects.all()

    datos ={
        'contacto': contacto
    }
    return render(request,'core/bdd.html',datos)


def formularioContacto(request):
    

    datos ={
        'form': ContactoForms()
    }


    if request.method == 'POST':
        formulario = ContactoForms(request.POST)

        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = 'Datos guardados exitosamente'
        else:
            datos['mensaje'] = 'error'   
    return render(request,'core/formularioContacto.html',datos)




  
def modificarContacto(request,id):
    contacto = Contacto.objects.get(rut=id)
    datos={
        'form' : ContactoForms(instance=contacto)    
    }

    if request.method == 'POST':
        formulario = ContactoForms(data=request.POST,instance=contacto)

        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = 'Datos modificados exitosamente'

    return render(request,'core/modificarContacto.html',datos)


def eliminarContacto(request,id):
    contacto=Contacto.objects.get(rut=id)
    contacto.delete()

    return redirect(to=bdd)